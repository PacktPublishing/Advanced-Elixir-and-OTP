use Mix.Config

config :deck, size: 13
