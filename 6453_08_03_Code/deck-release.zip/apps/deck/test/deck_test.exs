defmodule DeckTest do
  use ExUnit.Case
  doctest Deck

  test "the truth" do
    assert true
  end
end
