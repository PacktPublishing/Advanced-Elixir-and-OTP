use Mix.Config

config :deck, size: 54
