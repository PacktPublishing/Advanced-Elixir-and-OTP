use Mix.Config

config :deck, size: 52
