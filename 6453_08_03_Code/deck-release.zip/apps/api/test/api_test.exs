defmodule ApiTest do
  use ExUnit.Case
  doctest Api

  test "tests the truth" do
    assert true
  end
end
