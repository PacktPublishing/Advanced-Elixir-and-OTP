# Deck

A simple card deck application with supervision.
