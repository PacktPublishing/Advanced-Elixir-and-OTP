# Deck

A simple card deck implementation using a GenServer.
